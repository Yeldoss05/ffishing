<!DOCTYPE html>

<html  dir="ltr" lang="en" xml:lang="en" >
<head>
    <title>Log in to the site | SDU UNIVERSITY</title>
    <meta property="og:title" content="Log in to the site | SDU UNIVERSITY" />


    
    <meta name="theme-color" content="0#fff">

    <link rel="shortcut icon" href="https://moodle.sdu.edu.kz/pluginfile.php/1/theme_alpha/favicon/1732004874/logo_sdu_general_white%20%281%29%20%281%29.ico" />
    
    <link rel="icon" type"image/png" sizes="16x16" href="//moodle.sdu.edu.kz/pluginfile.php/1/theme_alpha/favicon16/1732004874/logo_sdu_general%20%281%29%20%282%29.png">
    
    

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="moodle, Log in to the site | SDU UNIVERSITY" />
<link rel="stylesheet" type="text/css" href="https://moodle.sdu.edu.kz/theme/yui_combo.php?rollup/3.18.1/yui-moodlesimple-min.css" /><script id="firstthemesheet" type="text/css">/** Required in order to fix style inclusion problems in IE with YUI **/</script><link rel="stylesheet" type="text/css" href="https://moodle.sdu.edu.kz/theme/styles.php/alpha/1732004874_1/all" />
<script>
//<![CDATA[
var M = {}; M.yui = {};
M.pageloadstarttime = new Date();
M.cfg = {"wwwroot":"https:\/\/moodle.sdu.edu.kz","homeurl":{},"sesskey":"jpNtuuXM6C","sessiontimeout":"28800","sessiontimeoutwarning":"1200","themerev":"1732004874","slasharguments":1,"theme":"alpha","iconsystemmodule":"core\/icon_system_fontawesome","jsrev":"1732004874","admin":"admin","svgicons":true,"usertimezone":"Asia\/Almaty","language":"en","courseId":1,"courseContextId":2,"contextid":1,"contextInstanceId":0,"langrev":1733959323,"templaterev":"1732004874","siteId":1};var yui1ConfigFn = function(me) {if(/-skin|reset|fonts|grids|base/.test(me.name)){me.type='css';me.path=me.path.replace(/\.js/,'.css');me.path=me.path.replace(/\/yui2-skin/,'/assets/skins/sam/yui2-skin')}};
var yui2ConfigFn = function(me) {var parts=me.name.replace(/^moodle-/,'').split('-'),component=parts.shift(),module=parts[0],min='-min';if(/-(skin|core)$/.test(me.name)){parts.pop();me.type='css';min=''}
if(module){var filename=parts.join('-');me.path=component+'/'+module+'/'+filename+min+'.'+me.type}else{me.path=component+'/'+component+'.'+me.type}};
YUI_config = {"debug":false,"base":"https:\/\/moodle.sdu.edu.kz\/lib\/yuilib\/3.18.1\/","comboBase":"https:\/\/moodle.sdu.edu.kz\/theme\/yui_combo.php?","combine":true,"filter":null,"insertBefore":"firstthemesheet","groups":{"yui2":{"base":"https:\/\/moodle.sdu.edu.kz\/lib\/yuilib\/2in3\/2.9.0\/build\/","comboBase":"https:\/\/moodle.sdu.edu.kz\/theme\/yui_combo.php?","combine":true,"ext":false,"root":"2in3\/2.9.0\/build\/","patterns":{"yui2-":{"group":"yui2","configFn":yui1ConfigFn}}},"moodle":{"name":"moodle","base":"https:\/\/moodle.sdu.edu.kz\/theme\/yui_combo.php?m\/1732004874\/","combine":true,"comboBase":"https:\/\/moodle.sdu.edu.kz\/theme\/yui_combo.php?","ext":false,"root":"m\/1732004874\/","patterns":{"moodle-":{"group":"moodle","configFn":yui2ConfigFn}},"filter":null,"modules":{"moodle-core-actionmenu":{"requires":["base","event","node-event-simulate"]},"moodle-core-event":{"requires":["event-custom"]},"moodle-core-handlebars":{"condition":{"trigger":"handlebars","when":"after"}},"moodle-core-chooserdialogue":{"requires":["base","panel","moodle-core-notification"]},"moodle-core-notification":{"requires":["moodle-core-notification-dialogue","moodle-core-notification-alert","moodle-core-notification-confirm","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-core-notification-dialogue":{"requires":["base","node","panel","escape","event-key","dd-plugin","moodle-core-widget-focusafterclose","moodle-core-lockscroll"]},"moodle-core-notification-alert":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-confirm":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-exception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-ajaxexception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-maintenancemodetimer":{"requires":["base","node"]},"moodle-core-lockscroll":{"requires":["plugin","base-build"]},"moodle-core-dragdrop":{"requires":["base","node","io","dom","dd","event-key","event-focus","moodle-core-notification"]},"moodle-core-blocks":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification"]},"moodle-core_availability-form":{"requires":["base","node","event","event-delegate","panel","moodle-core-notification-dialogue","json"]},"moodle-backup-backupselectall":{"requires":["node","event","node-event-simulate","anim"]},"moodle-course-util":{"requires":["node"],"use":["moodle-course-util-base"],"submodules":{"moodle-course-util-base":{},"moodle-course-util-section":{"requires":["node","moodle-course-util-base"]},"moodle-course-util-cm":{"requires":["node","moodle-course-util-base"]}}},"moodle-course-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-course-coursebase","moodle-course-util"]},"moodle-course-management":{"requires":["base","node","io-base","moodle-core-notification-exception","json-parse","dd-constrain","dd-proxy","dd-drop","dd-delegate","node-event-delegate"]},"moodle-course-categoryexpander":{"requires":["node","event-key"]},"moodle-form-shortforms":{"requires":["node","base","selector-css3","moodle-core-event"]},"moodle-form-dateselector":{"requires":["base","node","overlay","calendar"]},"moodle-question-chooser":{"requires":["moodle-core-chooserdialogue"]},"moodle-question-searchform":{"requires":["base","node"]},"moodle-availability_completion-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_date-form":{"requires":["base","node","event","io","moodle-core_availability-form"]},"moodle-availability_grade-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_group-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_grouping-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_profile-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-mod_assign-history":{"requires":["node","transition"]},"moodle-mod_customcert-rearrange":{"requires":["dd-delegate","dd-drag"]},"moodle-mod_quiz-toolboxes":{"requires":["base","node","event","event-key","io","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-slot","moodle-core-notification-ajaxexception"]},"moodle-mod_quiz-quizbase":{"requires":["base","node"]},"moodle-mod_quiz-autosave":{"requires":["base","node","event","event-valuechange","node-event-delegate","io-form","datatype-date-format"]},"moodle-mod_quiz-questionchooser":{"requires":["moodle-core-chooserdialogue","moodle-mod_quiz-util","querystring-parse"]},"moodle-mod_quiz-util":{"requires":["node","moodle-core-actionmenu"],"use":["moodle-mod_quiz-util-base"],"submodules":{"moodle-mod_quiz-util-base":{},"moodle-mod_quiz-util-slot":{"requires":["node","moodle-mod_quiz-util-base"]},"moodle-mod_quiz-util-page":{"requires":["node","moodle-mod_quiz-util-base"]}}},"moodle-mod_quiz-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-base","moodle-mod_quiz-util-page","moodle-mod_quiz-util-slot","moodle-course-util"]},"moodle-mod_quiz-modform":{"requires":["base","node","event"]},"moodle-message_airnotifier-toolboxes":{"requires":["base","node","io"]},"moodle-editor_atto-editor":{"requires":["node","transition","io","overlay","escape","event","event-simulate","event-custom","node-event-html5","node-event-simulate","yui-throttle","moodle-core-notification-dialogue","moodle-editor_atto-rangy","handlebars","timers","querystring-stringify"]},"moodle-editor_atto-plugin":{"requires":["node","base","escape","event","event-outside","handlebars","event-custom","timers","moodle-editor_atto-menu"]},"moodle-editor_atto-menu":{"requires":["moodle-core-notification-dialogue","node","event","event-custom"]},"moodle-editor_atto-rangy":{"requires":[]},"moodle-report_eventlist-eventfilter":{"requires":["base","event","node","node-event-delegate","datatable","autocomplete","autocomplete-filters"]},"moodle-report_loglive-fetchlogs":{"requires":["base","event","node","io","node-event-delegate"]},"moodle-gradereport_history-userselector":{"requires":["escape","event-delegate","event-key","handlebars","io-base","json-parse","moodle-core-notification-dialogue"]},"moodle-qbank_editquestion-chooser":{"requires":["moodle-core-chooserdialogue"]},"moodle-tool_lp-dragdrop-reorder":{"requires":["moodle-core-dragdrop"]},"moodle-assignfeedback_editpdf-editor":{"requires":["base","event","node","io","graphics","json","event-move","event-resize","transition","querystring-stringify-simple","moodle-core-notification-dialog","moodle-core-notification-alert","moodle-core-notification-warning","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-atto_accessibilitychecker-button":{"requires":["color-base","moodle-editor_atto-plugin"]},"moodle-atto_accessibilityhelper-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_aic-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_align-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_bold-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_charmap-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_clear-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_collapse-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_emojipicker-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_emoticon-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_equation-button":{"requires":["moodle-editor_atto-plugin","moodle-core-event","io","event-valuechange","tabview","array-extras"]},"moodle-atto_h5p-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_html-codemirror":{"requires":["moodle-atto_html-codemirror-skin"]},"moodle-atto_html-beautify":{},"moodle-atto_html-button":{"requires":["promise","moodle-editor_atto-plugin","moodle-atto_html-beautify","moodle-atto_html-codemirror","event-valuechange"]},"moodle-atto_image-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_indent-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_italic-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_link-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_managefiles-usedfiles":{"requires":["node","escape"]},"moodle-atto_managefiles-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_media-button":{"requires":["moodle-editor_atto-plugin","moodle-form-shortforms"]},"moodle-atto_noautolink-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_orderedlist-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_recordrtc-recording":{"requires":["moodle-atto_recordrtc-button"]},"moodle-atto_recordrtc-button":{"requires":["moodle-editor_atto-plugin","moodle-atto_recordrtc-recording"]},"moodle-atto_rtl-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_strike-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_subscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_superscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_table-button":{"requires":["moodle-editor_atto-plugin","moodle-editor_atto-menu","event","event-valuechange"]},"moodle-atto_title-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_underline-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_undo-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_unorderedlist-button":{"requires":["moodle-editor_atto-plugin"]}}},"gallery":{"name":"gallery","base":"https:\/\/moodle.sdu.edu.kz\/lib\/yuilib\/gallery\/","combine":true,"comboBase":"https:\/\/moodle.sdu.edu.kz\/theme\/yui_combo.php?","ext":false,"root":"gallery\/1732004874\/","patterns":{"gallery-":{"group":"gallery"}}}},"modules":{"core_filepicker":{"name":"core_filepicker","fullpath":"https:\/\/moodle.sdu.edu.kz\/lib\/javascript.php\/1732004874\/repository\/filepicker.js","requires":["base","node","node-event-simulate","json","async-queue","io-base","io-upload-iframe","io-form","yui2-treeview","panel","cookie","datatable","datatable-sort","resize-plugin","dd-plugin","escape","moodle-core_filepicker","moodle-core-notification-dialogue"]},"core_comment":{"name":"core_comment","fullpath":"https:\/\/moodle.sdu.edu.kz\/lib\/javascript.php\/1732004874\/comment\/comment.js","requires":["base","io-base","node","json","yui2-animation","overlay","escape"]}},"logInclude":[],"logExclude":[],"logLevel":null};
M.yui.loader = {modules: {}};

//]]>
</script>

<meta name="robots" content="noindex" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap" rel="stylesheet">


    

</head>

<body  id="page-login-index" class="format-site role-none  path-login dir-ltr lang-en yui-skin-sam yui3-skin-sam moodle-sdu-edu-kz pagelayout-login course-1 context-1 notloggedin theme rui-login-page rui-login-layout-3">
    <div class="toast-wrapper mx-auto py-0 fixed-top" role="status" aria-live="polite"></div>

    <div>
    <a class="sr-only sr-only-focusable" href="#maincontent">Skip to main content</a>
</div><script src="https://moodle.sdu.edu.kz/lib/javascript.php/1732004874/lib/polyfills/polyfill.js"></script>
<script src="https://moodle.sdu.edu.kz/theme/yui_combo.php?rollup/3.18.1/yui-moodlesimple-min.js"></script><script src="https://moodle.sdu.edu.kz/lib/javascript.php/1732004874/lib/javascript-static.js"></script>
<script>
//<![CDATA[
document.body.className += ' jsenabled';
//]]>
</script>



    <div class="rui-login-lang-wrapper"><div class="rui-navbar-lang dropup">
    <button class="rui-topbar-btn rui-lang-btn text-decoration-none" id="drop-down-675d30e38978e675d30e387c934" data-toggle="dropdown" aria-haspopup="true" role="button" aria-label="Languages" aria-expanded="false">
        <svg class="ml-md-2" width="24" height="24" fill="none" viewBox="0 0 24 24">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.75 19.25L5.75 13.25M5.75 13.25L5.75 5.75C5.75 5.75 8.5 3.5 12 5.75C15.5 8 18.25 5.75 18.25 5.75L18.25 13.25C18.25 13.25 15.5 15.5 12 13.25C8.5 11 5.75 13.25 5.75 13.25Z"></path>
        </svg>
        <span class="rui-lang-btn-text ml-2 mr-2 text-uppercase">en</span>
    </button>
    <div class="dropdown-menu" aria-labelledby="drop-down-675d30e38978e675d30e387c934">
                <a class="dropdown-item" href="https://moodle.sdu.edu.kz/login/index.php?lang=en" title="Language">English ‎(en)‎</a>
                <a class="dropdown-item" href="https://moodle.sdu.edu.kz/login/index.php?lang=tr" title="Language">Türkçe ‎(tr)‎</a>
                <a class="dropdown-item" href="https://moodle.sdu.edu.kz/login/index.php?lang=kk" title="Language">Қазақша ‎(kk)‎</a>
                <a class="dropdown-item" href="https://moodle.sdu.edu.kz/login/index.php?lang=ru" title="Language">Русский ‎(ru)‎</a>
    </div>
</div></div>

    <div id="page-login" class="container-fluid p-0 rui-multilang">
        <div id="page-content" class="row no-gutters">
            <div id="region-main-box" class="col-12">
                <section id="region-main" aria-label="Content">
                    <div class="login-wrapper">
                        <div class="login-container">
                            <div class="main-content" role="main"><span id="maincontent"></span><div class="rui-login-layout 
        rui-login-layout-img 
         
         
        
        
        rui-login-layout--3
        
        
        ">




        <div class="rui-login-wrapper">
            <div class="rui-login-top-wrapper">



    </div>
    </div>

    <div class="rui-login-wrapper row no-gutters align-items-center justify-content-center w-100">
        <div class="rui-login-container row no-gutters">


<div class="rui-login-box">
    <div class="rui-login-content">

        <div class="rui-loginpage-intro">
                <div class="rui-loginpage-intro-logo dark-mode-logo ">
                        <a href="https://moodle.sdu.edu.kz" class="text-decoration-none">
                            <h1><img src="//moodle.sdu.edu.kz/pluginfile.php/1/theme_alpha/customloginlogo/1732004874/logo_sdu_general%20%281%29%20%282%29.png" title="SDU Moodle" alt="SDU Moodle" class="rui-login-logo img-fluid" /></h1>
                            <h1><img src="//moodle.sdu.edu.kz/pluginfile.php/1/theme_alpha/customlogindmlogo/1732004874/SDU-1058%20%281%29%20%281%29.jpg" alt="SDU Moodle" class="rui-custom-dmlogo ml-2 img-fluid" /></h1>
                        </a>

                </div>


        </div>



        <div class="rui-login-form">

            <form action="https://moodle.sdu.edu.kz/login/index.php" method="post" id="login">
                <input id="anchor" type="hidden" name="anchor" value="">
                <script>
                    document.getElementById('anchor').value = location.hash;
                </script>
                <input type="hidden" name="logintoken" value="koXbNDvGiT7SYc9pM3dQia5cUQPRdcd1">
                <div class="form-group mb-2 form-control--username-box">
                    <label for="username" class="sr-only">
                            Username or email
                    </label>
                    <input type="text" name="username" id="username" class="form-control form-control--username" value="" placeholder="Username or email" autocomplete="username">
                </div>
                <div class="form-group my-1 form-control--password-box">
                    <label for="password" class="sr-only">Password</label>
                    <input type="password" name="password" id="password" value="" class="form-control form-control--password" placeholder="Password" autocomplete="current-password">
                    <button class="rui-show-password-btn rui-show-password-btn--hidden border-0" id="togglePassword" tabindex="0" type="button" role="button" aria-checked="false" title="Show/Hide Password">
                        <span class="sr-only">Show/Hide Password</span>
                        <svg class="showpassword-icon--off" width="24" height="24" fill="none" viewBox="0 0 24 24">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19.25 12C19.25 13 17.5 18.25 12 18.25C6.5 18.25 4.75 13 4.75 12C4.75 11 6.5 5.75 12 5.75C17.5 5.75 19.25 11 19.25 12Z"></path>
                            <circle cx="12" cy="12" r="2.25" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"></circle>
                        </svg>
                        <svg class="showpassword-icon--on" width="24" height="24" fill="none" viewBox="0 0 24 24">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M18.6247 10C19.0646 10.8986 19.25 11.6745 19.25 12C19.25 13 17.5 18.25 12 18.25C11.2686 18.25 10.6035 18.1572 10 17.9938M7 16.2686C5.36209 14.6693 4.75 12.5914 4.75 12C4.75 11 6.5 5.75 12 5.75C13.7947 5.75 15.1901 6.30902 16.2558 7.09698"></path>
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19.25 4.75L4.75 19.25"></path>
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M10.409 13.591C9.53033 12.7123 9.53033 11.2877 10.409 10.409C11.2877 9.5303 12.7123 9.5303 13.591 10.409"></path>
                        </svg>
                    </button>
                </div>
                    <div class="w-100 text-center">
                        <a class="rui-login-forgot-btn" href="https://moodle.sdu.edu.kz/login/forgot_password.php">Forgotten your username or password?</a>
                    </div>
                
                <button type="submit" class="btn btn-lg btn-primary btn-block mt-3" id="loginbtn">Log in</button>
            </form>
        </div><!-- .rui-login-form -->


        <div class="rui-login-additional-btns">
            <hr class="hr-small" />
                <div class="rui-canloginasguest mt-2" title="Some courses may allow guest access">
                    <p class="small text-center">Some courses may allow guest access</p>
                    <form action="https://moodle.sdu.edu.kz/login/index.php" method="post" id="guestlogin">
                        <input type="hidden" name="logintoken" value="koXbNDvGiT7SYc9pM3dQia5cUQPRdcd1">
                        <input type="hidden" name="username" value="guest" />
                        <input type="hidden" name="password" value="guest" />
                        <button class="btn btn-sm btn-outline-secondary w-100" type="submit" id="loginguestbtn">Access as a guest</button>
                    </form>
                </div>
        </div><!-- .rui-additional-btns -->




    </div><!-- .rui-login-content -->

</div><!-- .rui-login-box -->



    <div class="rui-login-bg-container" style="background-image: url('//moodle.sdu.edu.kz/pluginfile.php/1/theme_alpha/loginbg/1732004874/SDU-1058%20%281%29%20%281%29.jpg');" alt="Image">
    </div>

    </div>
    </div>

    <div class="rui-login-wrapper">


    </div>

<button type="button" class="btn btn-xs btn-dark btn--cookie"  data-modal="alert"  data-modal-title-str='["cookiesenabled", "core"]'  data-modal-content-str='["cookiesenabled_help_html", "core"]' >
    <svg width="20" height="20" fill="none" viewBox="0 0 24 24">
        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 13V15"></path>
        <circle cx="12" cy="9" r="1" fill="currentColor"></circle>
        <circle cx="12" cy="12" r="7.25" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"></circle>
    </svg>

    <span class="ml-1">Cookies notice</span></button>

</div><!-- .login layout -->

<script>
    const togglePassword = document.querySelector("#togglePassword");
    const password = document.querySelector("#password");

    togglePassword.addEventListener("click", function() {
        // toggle the type attribute
        const type = password.getAttribute("type") === "password" ? "text" : "password";
        password.setAttribute("type", type);

        // toggle the icon
        this.classList.toggle("rui-show-password-btn--hidden");
    });
</script></div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>

    
    <script>
//<![CDATA[
var require = {
    baseUrl : 'https://moodle.sdu.edu.kz/lib/requirejs.php/1732004874/',
    // We only support AMD modules with an explicit define() statement.
    enforceDefine: true,
    skipDataMain: true,
    waitSeconds : 0,

    paths: {
        jquery: 'https://moodle.sdu.edu.kz/lib/javascript.php/1732004874/lib/jquery/jquery-3.7.1.min',
        jqueryui: 'https://moodle.sdu.edu.kz/lib/javascript.php/1732004874/lib/jquery/ui-1.13.2/jquery-ui.min',
        jqueryprivate: 'https://moodle.sdu.edu.kz/lib/javascript.php/1732004874/lib/requirejs/jquery-private'
    },

    // Custom jquery config map.
    map: {
      // '*' means all modules will get 'jqueryprivate'
      // for their 'jquery' dependency.
      '*': { jquery: 'jqueryprivate' },
      // Stub module for 'process'. This is a workaround for a bug in MathJax (see MDL-60458).
      '*': { process: 'core/first' },

      // 'jquery-private' wants the real jQuery module
      // though. If this line was not here, there would
      // be an unresolvable cyclic dependency.
      jqueryprivate: { jquery: 'jquery' }
    }
};

//]]>
</script>
<script src="https://moodle.sdu.edu.kz/lib/javascript.php/1732004874/lib/requirejs/require.min.js"></script>
<script>
//<![CDATA[
M.util.js_pending("core/first");
require(['core/first'], function() {
require(['core/prefetch'])
;
M.util.js_pending('filter_mathjaxloader/loader'); require(['filter_mathjaxloader/loader'], function(amd) {amd.configure({"mathjaxconfig":"\nMathJax.Hub.Config({\n    config: [\"Accessible.js\", \"Safe.js\"],\n    errorSettings: { message: [\"!\"] },\n    skipStartupTypeset: true,\n    messageStyle: \"none\"\n});\n","lang":"en"}); M.util.js_complete('filter_mathjaxloader/loader');});;
require(["media_videojs/loader"], function(loader) {
    loader.setUp('en');
});;

require(['jquery', 'core/custom_interaction_events'], function($, CustomEvents) {
    CustomEvents.define('#single_select675d30e387c933', [CustomEvents.events.accessibleChange]);
    $('#single_select675d30e387c933').on(CustomEvents.events.accessibleChange, function() {
        var ignore = $(this).find(':selected').attr('data-ignore');
        if (typeof ignore === typeof undefined) {
            $('#single_select_f675d30e387c932').submit();
        }
    });
});
;

require(['jquery', 'core/custom_interaction_events'], function($, CustomEvents) {
    CustomEvents.define('#single_select675d30e387c936', [CustomEvents.events.accessibleChange]);
    $('#single_select675d30e387c936').on(CustomEvents.events.accessibleChange, function() {
        var ignore = $(this).find(':selected').attr('data-ignore');
        if (typeof ignore === typeof undefined) {
            $('#single_select_f675d30e387c935').submit();
        }
    });
});
;

M.util.js_pending('theme_alpha/loader');
require(['theme_alpha/loader'], function() {
  M.util.js_complete('theme_alpha/loader');
});
;

    require(['core_form/submit'], function(Submit) {
        Submit.init("loginbtn");
            Submit.init("loginguestbtn");
    });
;
M.util.js_pending('core/notification'); require(['core/notification'], function(amd) {amd.init(1, []); M.util.js_complete('core/notification');});;
M.util.js_pending('core/log'); require(['core/log'], function(amd) {amd.setConfig({"level":"warn"}); M.util.js_complete('core/log');});;
M.util.js_pending('core/page_global'); require(['core/page_global'], function(amd) {amd.init(); M.util.js_complete('core/page_global');});;
M.util.js_pending('core/utility'); require(['core/utility'], function(amd) {M.util.js_complete('core/utility');});;
M.util.js_pending('core/storage_validation'); require(['core/storage_validation'], function(amd) {amd.init(null); M.util.js_complete('core/storage_validation');});
    M.util.js_complete("core/first");
});
//]]>
</script>
<script src="https://cdn.jsdelivr.net/npm/mathjax@2.7.9/MathJax.js?delayStartupUntil=configured"></script>
<script>
//<![CDATA[
M.str = {"moodle":{"lastmodified":"Last modified","name":"Name","error":"Error","info":"Information","yes":"Yes","no":"No","cancel":"Cancel","confirm":"Confirm","areyousure":"Are you sure?","closebuttontitle":"Close","unknownerror":"Unknown error","file":"File","url":"URL","collapseall":"Collapse all","expandall":"Expand all"},"repository":{"type":"Type","size":"Size","invalidjson":"Invalid JSON string","nofilesattached":"No files attached","filepicker":"File picker","logout":"Logout","nofilesavailable":"No files available","norepositoriesavailable":"Sorry, none of your current repositories can return files in the required format.","fileexistsdialogheader":"File exists","fileexistsdialog_editor":"A file with that name has already been attached to the text you are editing.","fileexistsdialog_filemanager":"A file with that name has already been attached","renameto":"Rename to \"{$a}\"","referencesexist":"There are {$a} links to this file","select":"Select"},"admin":{"confirmdeletecomments":"Are you sure you want to delete the selected comment(s)?","confirmation":"Confirmation"},"debug":{"debuginfo":"Debug info","line":"Line","stacktrace":"Stack trace"},"langconfig":{"labelsep":": "}};
//]]>
</script>
<script>
//<![CDATA[
(function() {M.util.help_popups.setup(Y);
 M.util.js_pending('random675d30e387c9312'); Y.on('domready', function() { M.util.js_complete("init");  M.util.js_complete('random675d30e387c9312'); });
})();
//]]>
</script>



</body></html>